'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { CalendarIcon, Save, Download, Upload, User, ChevronDown, ChevronUp, Trash2, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Solar, Lunar } from 'lunar-javascript';
import * as XLSX from 'xlsx';

// 24小时时辰列表（1小时粒度）
const TIME_PERIODS = Array.from({ length: 24 }, (_, i) => ({
  value: i.toString(),
  label: `${i.toString().padStart(2, '0')}:00`,
  hour: i,
}));

export interface BirthInfo {
  name: string;
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  gender: 'male' | 'female';
  solar: Solar;
  lunar: Lunar;
}

// 保存的数据结构（不含 Solar/Lunar 对象）
interface SavedBirthData {
  id: string;
  name: string;
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  gender: 'male' | 'female';
  savedAt: number;
}

interface BirthInputProps {
  onBirthInfoChange: (info: BirthInfo) => void;
}

export function BirthInput({ onBirthInfoChange }: BirthInputProps) {
  const [name, setName] = useState<string>('');
  const [yearInput, setYearInput] = useState<string>('1990');
  const [monthInput, setMonthInput] = useState<string>('6');
  const [dayInput, setDayInput] = useState<string>('22');
  const [date, setDate] = useState<Date | undefined>(new Date(1990, 5, 22));
  const [hour, setHour] = useState<string>('8');
  const [minute, setMinute] = useState<string>('0');
  const [gender, setGender] = useState<'male' | 'female'>('female');
  const [timePeriod, setTimePeriod] = useState<string>('7');
  
  // 保存的数据列表
  const [savedList, setSavedList] = useState<SavedBirthData[]>([]);
  const [showSavedList, setShowSavedList] = useState<boolean>(false);
  
  // 导入选择对话框
  const [importDialogOpen, setImportDialogOpen] = useState<boolean>(false);
  const [importedDataList, setImportedDataList] = useState<SavedBirthData[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  
  // 文件上传引用
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 从 localStorage 加载保存的数据
  useEffect(() => {
    const saved = localStorage.getItem('birthInfoList');
    if (saved) {
      try {
        setSavedList(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load saved data:', e);
      }
    }
  }, []);

  // 更新出生信息
  useEffect(() => {
    if (!date) return;
    
    // 根据时辰设置小时
    const period = TIME_PERIODS.find(p => p.value === timePeriod);
    const selectedHour = period ? period.hour : 6;
    
    const solar = Solar.fromDate(new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      selectedHour,
      parseInt(minute)
    ));
    
    const lunar = solar.getLunar();
    
    onBirthInfoChange({
      name,
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      day: date.getDate(),
      hour: selectedHour,
      minute: parseInt(minute),
      gender,
      solar,
      lunar,
    });
  }, [name, date, timePeriod, minute, gender, onBirthInfoChange]);

  // 数字输入变化时同步更新日期选择器
  const handleNumberInputChange = () => {
    const parsedYear = parseInt(yearInput);
    const parsedMonth = parseInt(monthInput);
    const parsedDay = parseInt(dayInput);
    
    // 如果解析失败，不更新
    if (isNaN(parsedYear) || isNaN(parsedMonth) || isNaN(parsedDay)) {
      return;
    }
    
    const year = Math.max(1900, Math.min(2100, parsedYear));
    const month = Math.max(1, Math.min(12, parsedMonth));
    const day = Math.max(1, Math.min(31, parsedDay));
    
    // 验证日期有效性
    const maxDay = new Date(year, month, 0).getDate();
    const validDay = Math.min(day, maxDay);
    
    const newDate = new Date(year, month - 1, validDay);
    if (newDate.getFullYear() === year && newDate.getMonth() === month - 1) {
      setDate(newDate);
      // 同步更新输入框显示正确的值
      setYearInput(year.toString());
      setMonthInput(month.toString());
      setDayInput(validDay.toString());
    }
  };

  // 日期选择器变化时同步更新数字输入
  const handleDateChange = (newDate: Date | undefined) => {
    setDate(newDate);
    if (newDate) {
      setYearInput(newDate.getFullYear().toString());
      setMonthInput((newDate.getMonth() + 1).toString());
      setDayInput(newDate.getDate().toString());
    }
  };

  // 保存当前数据
  const handleSave = () => {
    if (!date) return;
    
    const period = TIME_PERIODS.find(p => p.value === timePeriod);
    const selectedHour = period ? period.hour : 6;
    
    const newData: SavedBirthData = {
      id: Date.now().toString(),
      name: name || '未命名',
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      day: date.getDate(),
      hour: selectedHour,
      minute: parseInt(minute),
      gender,
      savedAt: Date.now(),
    };
    
    const updatedList = [...savedList, newData];
    setSavedList(updatedList);
    localStorage.setItem('birthInfoList', JSON.stringify(updatedList));
    
    // 提示保存成功
    alert('保存成功！');
  };

  // 加载保存的数据
  const handleLoadSaved = (data: SavedBirthData) => {
    setName(data.name);
    setYearInput(data.year.toString());
    setMonthInput(data.month.toString());
    setDayInput(data.day.toString());
    setDate(new Date(data.year, data.month - 1, data.day));
    setMinute(data.minute.toString());
    setGender(data.gender);
    
    // 根据小时找到对应时辰
    const period = TIME_PERIODS.find(p => p.hour === data.hour);
    if (period) {
      setTimePeriod(period.value);
    }
    
    setShowSavedList(false);
  };

  // 删除保存的数据
  const handleDeleteSaved = (id: string) => {
    const updatedList = savedList.filter(d => d.id !== id);
    setSavedList(updatedList);
    localStorage.setItem('birthInfoList', JSON.stringify(updatedList));
  };

  // 导出Excel
  const handleExportExcel = () => {
    if (savedList.length === 0) {
      alert('没有可导出的数据，请先保存一些数据！');
      return;
    }
    
    // 准备Excel数据
    const excelData = savedList.map((data, index) => ({
      '序号': index + 1,
      '姓名': data.name,
      '年份': data.year,
      '月份': data.month,
      '日期': data.day,
      '时辰': TIME_PERIODS.find(p => p.hour === data.hour)?.label || '',
      '分钟': data.minute,
      '性别': data.gender === 'male' ? '男' : '女',
      '保存时间': format(new Date(data.savedAt), 'yyyy-MM-dd HH:mm:ss'),
    }));
    
    // 创建工作簿
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(excelData);
    
    // 设置列宽
    ws['!cols'] = [
      { wch: 6 },   // 序号
      { wch: 15 },  // 姓名
      { wch: 8 },   // 年份
      { wch: 8 },   // 月份
      { wch: 8 },   // 日期
      { wch: 25 },  // 时辰
      { wch: 8 },   // 分钟
      { wch: 6 },   // 性别
      { wch: 20 },  // 保存时间
    ];
    
    XLSX.utils.book_append_sheet(wb, ws, '出生信息');
    
    // 下载文件
    XLSX.writeFile(wb, `天赋自在命理工具箱_出生信息_${format(new Date(), 'yyyyMMdd')}.xlsx`);
  };

  // 导入Excel
  const handleImportExcel = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet) as Record<string, unknown>[];
        
        // 转换数据格式
        const importedData: SavedBirthData[] = jsonData.map((row, index) => {
          const year = Number(row['年份']) || 1990;
          const month = Number(row['月份']) || 1;
          const day = Number(row['日期']) || 15;
          const minute = Number(row['分钟']) || 0;
          const genderStr = String(row['性别'] || '男');
          const hourStr = String(row['时辰'] || '');
          
          // 从时辰字符串提取小时
          let hour = 6;
          for (const p of TIME_PERIODS) {
            if (hourStr.includes(p.label.split(' ')[0])) {
              hour = p.hour;
              break;
            }
          }
          
          return {
            id: (Date.now() + index).toString(),
            name: String(row['姓名'] || '未命名'),
            year,
            month,
            day,
            hour,
            minute,
            gender: genderStr === '女' ? 'female' : 'male',
            savedAt: Date.now() + index,
          };
        });
        
        // 显示选择对话框
        setImportedDataList(importedData);
        setSelectedIndex(-1);
        setImportDialogOpen(true);
      } catch (err) {
        console.error('Import error:', err);
        alert('导入失败，请检查文件格式！');
      }
    };
    
    reader.readAsArrayBuffer(file);
    
    // 清空文件输入
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // 确认导入选中的数据
  const handleConfirmImport = () => {
    if (selectedIndex < 0 || selectedIndex >= importedDataList.length) {
      alert('请选择一条数据！');
      return;
    }
    
    const selectedData = importedDataList[selectedIndex];
    
    // 直接加载到输入框（不保存到列表）
    setName(selectedData.name);
    setYearInput(String(selectedData.year));
    setMonthInput(String(selectedData.month));
    setDayInput(String(selectedData.day));
    
    // 设置日期
    const newDate = new Date(selectedData.year, selectedData.month - 1, selectedData.day);
    setDate(newDate);
    
    // 设置时辰
    const period = TIME_PERIODS.find(p => p.hour === selectedData.hour);
    if (period) {
      setTimePeriod(period.value);
    }
    
    // 设置分钟
    setMinute(String(selectedData.minute));
    
    // 设置性别
    setGender(selectedData.gender);
    
    // 关闭对话框
    setImportDialogOpen(false);
    setImportedDataList([]);
    setSelectedIndex(-1);
  };

  // 将选中的数据保存到列表
  const handleImportAndSave = () => {
    if (selectedIndex < 0 || selectedIndex >= importedDataList.length) {
      alert('请选择一条数据！');
      return;
    }
    
    const selectedData = importedDataList[selectedIndex];
    
    // 添加到保存列表
    const updatedList = [...savedList, selectedData];
    setSavedList(updatedList);
    localStorage.setItem('birthInfoList', JSON.stringify(updatedList));
    
    // 同时加载到输入框
    handleConfirmImport();
    
    alert('已导入并保存该数据！');
  };

  return (
    <Card className="bg-gradient-to-b from-[#2a2624] to-[#1a1a1a] border-[#3a3530] shadow-lg">
      <CardHeader className="pb-3">
        <CardTitle className="text-[#d4c4f5] text-lg font-medium tracking-wider">出生信息</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* 用户名输入 */}
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-[#f5e6a3]" />
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="输入姓名（可选）"
            className="w-[200px] bg-[#2a2624] border-[#3a3530] text-[#fafaf9] placeholder:text-[#6a6a6a]"
          />
        </div>

        {/* 数字直接输入 */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-[#a0a0a0] text-sm w-8">年</span>
            <Input
              value={yearInput}
              onChange={(e) => setYearInput(e.target.value)}
              onBlur={handleNumberInputChange}
              onKeyDown={(e) => e.key === 'Enter' && handleNumberInputChange()}
              type="number"
              min="1900"
              max="2100"
              className="w-[80px] bg-[#2a2624] border-[#3a3530] text-[#fafaf9]"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-[#a0a0a0] text-sm w-8">月</span>
            <Input
              value={monthInput}
              onChange={(e) => setMonthInput(e.target.value)}
              onBlur={handleNumberInputChange}
              onKeyDown={(e) => e.key === 'Enter' && handleNumberInputChange()}
              type="number"
              min="1"
              max="12"
              className="w-[60px] bg-[#2a2624] border-[#3a3530] text-[#fafaf9]"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-[#a0a0a0] text-sm w-8">日</span>
            <Input
              value={dayInput}
              onChange={(e) => setDayInput(e.target.value)}
              onBlur={handleNumberInputChange}
              onKeyDown={(e) => e.key === 'Enter' && handleNumberInputChange()}
              type="number"
              min="1"
              max="31"
              className="w-[60px] bg-[#2a2624] border-[#3a3530] text-[#fafaf9]"
            />
          </div>

          {/* 日期选择器 */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-[180px] justify-start text-left font-normal bg-[#2a2624] border-[#3a3530] text-[#fafaf9]"
              >
                <CalendarIcon className="mr-2 h-4 w-4 text-[#d4c4f5]" />
                {date ? format(date, 'yyyy/MM/dd') : '选择日期'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 bg-[#2a2624] border-[#3a3530]" align="start">
              <Calendar
                mode="single"
                selected={date}
                onSelect={handleDateChange}
                initialFocus
                className="bg-[#2a2624] text-[#fafaf9]"
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* 时辰、分钟、性别 */}
        <div className="flex flex-wrap items-center gap-4">
          {/* 时辰选择 */}
          <div className="flex items-center gap-2">
            <span className="text-[#a0a0a0] text-sm w-12">时辰</span>
            <Select value={timePeriod} onValueChange={setTimePeriod}>
              <SelectTrigger className="w-[180px] bg-[#2a2624] border-[#3a3530] text-[#fafaf9]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#2a2624] border-[#3a3530]">
                {TIME_PERIODS.map((p) => (
                  <SelectItem key={p.value} value={p.value} className="text-[#fafaf9] focus:bg-[#3a3530]">
                    {p.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 分钟选择 */}
          <div className="flex items-center gap-2">
            <span className="text-[#a0a0a0] text-sm w-8">分</span>
            <Select value={minute} onValueChange={setMinute}>
              <SelectTrigger className="w-[80px] bg-[#2a2624] border-[#3a3530] text-[#fafaf9]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#2a2624] border-[#3a3530]">
                {Array.from({ length: 12 }, (_, i) => i * 5).map((m) => (
                  <SelectItem key={m.toString()} value={m.toString()} className="text-[#fafaf9] focus:bg-[#3a3530]">
                    {m.toString().padStart(2, '0')}分
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 性别选择 */}
          <div className="flex items-center gap-2">
            <span className="text-[#a0a0a0] text-sm w-12">性别</span>
            <Select value={gender} onValueChange={(v) => setGender(v as 'male' | 'female')}>
              <SelectTrigger className="w-[100px] bg-[#2a2624] border-[#3a3530] text-[#fafaf9]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#2a2624] border-[#3a3530]">
                <SelectItem value="male" className="text-[#fafaf9] focus:bg-[#3a3530]">男</SelectItem>
                <SelectItem value="female" className="text-[#fafaf9] focus:bg-[#3a3530]">女</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#3a3530]">
          <Button
            onClick={handleSave}
            className="bg-[#d4c4f5]/20 hover:bg-[#d4c4f5]/30 text-[#d4c4f5] border border-[#d4c4f5]/30"
          >
            <Save className="h-4 w-4 mr-2" />
            保存
          </Button>
          
          <Button
            onClick={() => setShowSavedList(!showSavedList)}
            className="bg-[#f5e6a3]/20 hover:bg-[#f5e6a3]/30 text-[#f5e6a3] border border-[#f5e6a3]/30"
          >
            {showSavedList ? <ChevronUp className="h-4 w-4 mr-2" /> : <ChevronDown className="h-4 w-4 mr-2" />}
            已保存 ({savedList.length})
          </Button>
          
          <Button
            onClick={handleExportExcel}
            className="bg-[#a8d5a2]/20 hover:bg-[#a8d5a2]/30 text-[#a8d5a2] border border-[#a8d5a2]/30"
          >
            <Download className="h-4 w-4 mr-2" />
            导出Excel
          </Button>
          
          <Button
            onClick={() => fileInputRef.current?.click()}
            className="bg-[#a5c8e8]/20 hover:bg-[#a5c8e8]/30 text-[#a5c8e8] border border-[#a5c8e8]/30"
          >
            <Upload className="h-4 w-4 mr-2" />
            导入Excel
          </Button>
          
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            onChange={handleImportExcel}
            className="hidden"
          />
        </div>

        {/* 已保存数据列表 */}
        {showSavedList && savedList.length > 0 && (
          <div className="mt-2 p-2 rounded-lg bg-[#1a1a1a] border-[#3a3530] max-h-[200px] overflow-y-auto">
            {savedList.map((data) => (
              <div
                key={data.id}
                className="flex items-center justify-between p-2 rounded hover:bg-[#2a2624] cursor-pointer group"
              >
                <div
                  className="flex-1 text-sm"
                  onClick={() => handleLoadSaved(data)}
                >
                  <span className="text-[#f5e6a3] font-medium">{data.name}</span>
                  <span className="text-[#a0a0a0] ml-2">
                    {data.year}年{data.month}月{data.day}日 
                    {TIME_PERIODS.find(p => p.hour === data.hour)?.label.split(' ')[0]}
                    {data.gender === 'male' ? '男' : '女'}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDeleteSaved(data.id)}
                  className="text-[#e8a5a5] hover:text-[#e8a5a5] hover:bg-[#e8a5a5]/10 opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}

        {/* 显示农历信息 */}
        {date && (
          <div className="mt-4 p-3 rounded-lg bg-[#1a1a1a] border-[#3a3530]">
            <div className="flex flex-wrap gap-6 text-sm">
              <div className="text-[#a0a0a0]">
                <span className="text-[#f5e6a3]">阳历：</span>
                {format(date, 'yyyy年MM月dd日', { locale: zhCN })}
              </div>
              <div className="text-[#a0a0a0]">
                <span className="text-[#f5e6a3]">农历：</span>
                {(() => {
                  const solar = Solar.fromDate(date);
                  const lunar = solar.getLunar();
                  return `${lunar.toString()} (${lunar.getMonthInChinese()}月${lunar.getDayInChinese()})`;
                })()}
              </div>
              <div className="text-[#a0a0a0]">
                <span className="text-[#f5e6a3]">节气：</span>
                {(() => {
                  const solar = Solar.fromDate(date);
                  const lunar = solar.getLunar();
                  const prevJie = lunar.getPrevJieQi();
                  const nextJie = lunar.getNextJieQi();
                  const birthMs = new Date(solar.getYear(), solar.getMonth()-1, solar.getDay(), solar.getHour(), solar.getMinute()).getTime();
                  let jieName = '', prefix = '', diffDays = 0, diffHours = 0;
                  if (prevJie) {
                    const pj = prevJie.getSolar();
                    const prevMs = new Date(pj.getYear(), pj.getMonth()-1, pj.getDay(), pj.getHour(), pj.getMinute()).getTime();
                    const diffH = (birthMs - prevMs) / 3600000;
                    if (diffH >= 0 && diffH < 720) {
                      jieName = prevJie.getName();
                      prefix = '后';
                      diffDays = Math.floor(diffH / 24);
                      diffHours = Math.round(diffH % 24);
                    }
                  }
                  if (!jieName && nextJie) {
                    const nj = nextJie.getSolar();
                    const nextMs = new Date(nj.getYear(), nj.getMonth()-1, nj.getDay(), nj.getHour(), nj.getMinute()).getTime();
                    const diffH = (nextMs - birthMs) / 3600000;
                    if (diffH >= 0 && diffH < 720) {
                      jieName = nextJie.getName();
                      prefix = '前';
                      diffDays = Math.floor(diffH / 24);
                      diffHours = Math.round(diffH % 24);
                    }
                  }
                  return jieName ? `${jieName}${prefix} ${diffDays}天${diffHours}小时` : '无';
                })()}
              </div>
              
            </div>
          </div>
        )}
      </CardContent>

      {/* 导入选择对话框 */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent className="bg-[#2a2624] border-[#3a3530] text-[#fafaf9] max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#d4c4f5]">选择要导入的数据</DialogTitle>
            <DialogDescription className="text-[#a0a0a0]">
              Excel文件中共有 {importedDataList.length} 条数据，请选择要导入的一条
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="h-[300px] pr-4">
            <div className="space-y-2">
              {importedDataList.map((data, index) => (
                <div
                  key={index}
                  onClick={() => setSelectedIndex(index)}
                  className={cn(
                    "p-3 rounded-lg cursor-pointer transition-all",
                    selectedIndex === index 
                      ? "bg-[#d4c4f5]/20 border border-[#d4c4f5]/50" 
                      : "bg-[#1a1a1a] border border-[#3a3530] hover:border-[#d4c4f5]/30"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="text-[#f5e6a3] font-medium">
                        {index + 1}. {data.name}
                      </div>
                      <div className="text-[#a0a0a0] text-sm mt-1">
                        {data.year}年{data.month}月{data.day}日 
                        {TIME_PERIODS.find(p => p.hour === data.hour)?.label.split(' ')[0]}
                        {data.minute}分
                        {data.gender === 'male' ? '男' : '女'}
                      </div>
                    </div>
                    {selectedIndex === index && (
                      <Check className="h-5 w-5 text-[#d4c4f5]" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
          
          <DialogFooter className="gap-2 sm:gap-2">
            <Button
              onClick={handleConfirmImport}
              className="bg-[#d4c4f5]/20 hover:bg-[#d4c4f5]/30 text-[#d4c4f5] border border-[#d4c4f5]/30"
            >
              仅加载（不保存）
            </Button>
            <Button
              onClick={handleImportAndSave}
              className="bg-[#f5e6a3]/20 hover:bg-[#f5e6a3]/30 text-[#f5e6a3] border border-[#f5e6a3]/30"
            >
              导入并保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}