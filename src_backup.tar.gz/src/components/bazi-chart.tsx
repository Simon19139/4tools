'use client';

import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Solar, Lunar } from 'lunar-javascript';
import { cn } from '@/lib/utils';
import { Maximize2, Minimize2 } from 'lucide-react';

// 天干序列
const GAN_SEQ = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
// 地支序列
const ZHI_SEQ = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

// 天干颜色配置 - 淡紫色和淡黄色系
const TIAN_GAN_COLORS: Record<string, string> = {
  '甲': '#a8d5a2', // 木 - 柔和青绿
  '乙': '#a8d5a2', // 木 - 柔和青绿
  '丙': '#e8a5a5', // 火 - 柔淡红
  '丁': '#e8a5a5', // 火 - 柔淡红
  '戊': '#f5e6a3', // 土 - 淡黄色
  '己': '#f5e6a3', // 土 - 淡黄色
  '庚': '#b8a5d6', // 金 - 淡紫色
  '辛': '#b8a5d6', // 金 - 淡紫色
  '壬': '#a5c8e8', // 水 - 柔淡蓝
  '癸': '#a5c8e8', // 水 - 柔淡蓝
};

// 地支颜色配置
const DI_ZHI_COLORS: Record<string, string> = {
  '子': '#a5c8e8', // 水
  '丑': '#f5e6a3', // 土
  '寅': '#a8d5a2', // 木
  '卯': '#a8d5a2', // 木
  '辰': '#f5e6a3', // 土
  '巳': '#e8a5a5', // 火
  '午': '#e8a5a5', // 火
  '未': '#f5e6a3', // 土
  '申': '#b8a5d6', // 金
  '酉': '#b8a5d6', // 金
  '戌': '#f5e6a3', // 土
  '亥': '#a5c8e8', // 水
};

// 五行颜色
const WU_XING_COLORS: Record<string, string> = {
  '木': '#a8d5a2',
  '火': '#e8a5a5',
  '土': '#f5e6a3',
  '金': '#b8a5d6',
  '水': '#a5c8e8',
};

// 天干对应五行
const GAN_WUXING: Record<string, string> = {
  '甲': '木', '乙': '木', '丙': '火', '丁': '火', '戊': '土',
  '己': '土', '庚': '金', '辛': '金', '壬': '水', '癸': '水',
};

// 地支对应五行
const ZHI_WUXING: Record<string, string> = {
  '子': '水', '丑': '土', '寅': '木', '卯': '木', '辰': '土',
  '巳': '火', '午': '火', '未': '土', '申': '金', '酉': '金',
  '戌': '土', '亥': '水',
};

// 地支藏干表
const ZHI_HIDE_GAN: Record<string, string[]> = {
  '子': ['癸'],
  '丑': ['己', '癸', '辛'],
  '寅': ['甲', '丙', '戊'],
  '卯': ['乙'],
  '辰': ['戊', '乙', '癸'],
  '巳': ['丙', '庚', '戊'],
  '午': ['丁', '己'],
  '未': ['己', '丁', '乙'],
  '申': ['庚', '壬', '戊'],
  '酉': ['辛'],
  '戌': ['戊', '辛', '丁'],
  '亥': ['壬', '甲'],
};

// 十神计算（以日干为主）
function calculateShiShen(dayGan: string, targetGan: string): string {
  if (targetGan === dayGan) return '比';
  
  const dayWuxing = GAN_WUXING[dayGan];
  const targetWuxing = GAN_WUXING[targetGan];
  
  // 判断阴阳
  const yangGans = ['甲', '丙', '戊', '庚', '壬'];
  const dayIsYang = yangGans.includes(dayGan);
  const targetIsYang = yangGans.includes(targetGan);
  const sameYinYang = dayIsYang === targetIsYang;
  
  // 五行生克关系
  const wuxingOrder = ['木', '火', '土', '金', '水'];
  const dayIndex = wuxingOrder.indexOf(dayWuxing);
  const targetIndex = wuxingOrder.indexOf(targetWuxing);
  
  const diff = (targetIndex - dayIndex + 5) % 5;
  
  // 生我者（印星）
  if (diff === 4) {
    return sameYinYang ? '偏印' : '正印';
  }
  // 我生者（食伤）
  if (diff === 1) {
    return sameYinYang ? '食神' : '伤官';
  }
  // 克我者（官杀）
  if (diff === 3) {
    return sameYinYang ? '七杀' : '正官';
  }
  // 我克者（财星）
  if (diff === 2) {
    return sameYinYang ? '偏财' : '正财';
  }
  // 同我者（比劫）
  if (diff === 0) {
    return sameYinYang ? '比肩' : '劫财';
  }
  
  return '';
}

// 十神简称映射
const SHISHEN_SHORT: Record<string, string> = {
  '比肩': '比',
  '劫财': '劫',
  '食神': '食',
  '伤官': '伤',
  '正财': '财',
  '偏财': '才',
  '正官': '官',
  '七杀': '杀',
  '正印': '印',
  '偏印': '枭',
  '比': '比',
  '日主': '日',
};

// 天乙贵人查找表（按日干）
const TIANYI_GUIREN: Record<string, string[]> = {
  '甲': ['丑', '未'], '乙': ['子', '申'], '丙': ['亥', '酉'],
  '丁': ['亥', '酉'], '戊': ['丑', '未'], '己': ['子', '申'],
  '庚': ['丑', '未'], '辛': ['午', '寅'], '壬': ['卯', '巳'],
  '癸': ['卯', '巳'],
};

// 文昌星查找表（按日干）
const WENCHANG: Record<string, string> = {
  '甲': '巳', '乙': '午', '丙': '申', '丁': '酉', '戊': '申',
  '己': '酉', '庚': '亥', '辛': '子', '壬': '寅', '癸': '卯',
};

// 驿马星查找表（按年支或日支）
const YIMA: Record<string, string> = {
  '申': '寅', '子': '寅', '辰': '寅', // 水局
  '寅': '申', '午': '申', '戌': '申', // 火局
  '巳': '亥', '酉': '亥', '丑': '亥', // 金局
  '亥': '巳', '卯': '巳', '未': '巳', // 木局
};

// 桃花星查找表（按年支或日支）
const TAOHUA: Record<string, string> = {
  '子': '酉', '辰': '酉', '申': '酉', // 水局
  '午': '卯', '戌': '卯', '寅': '卯', // 火局
  '酉': '午', '丑': '午', '巳': '午', // 金局
  '卯': '子', '未': '子', '亥': '子', // 木局
};

// 华盖星查找表（按年支）
const HUAGAI: Record<string, string> = {
  '子': '辰', '辰': '辰', '申': '辰', // 水局
  '午': '戌', '戌': '戌', '寅': '戌', // 火局
  '酉': '丑', '丑': '丑', '巳': '丑', // 金局
  '卯': '未', '未': '未', '亥': '未', // 木局
};

// 羊刃（按日干阳干查）
const YANGREN: Record<string, string> = {
  '甲': '卯', '丙': '午', '戊': '午', '庚': '酉', '壬': '子',
};

// 禄神（按日干查）
const LUSHEN: Record<string, string> = {
  '甲': '寅', '乙': '卯', '丙': '巳', '丁': '午', '戊': '巳',
  '己': '午', '庚': '申', '辛': '酉', '壬': '亥', '癸': '子',
};

// 计算某柱的神煞
function calculatePillarShenSha(
  dayGan: string,
  pillarZhi: string,
  yearZhi: string,
  allZhi: string[]
): string[] {
  const result: string[] = [];
  
  // 天乙贵人（按日干查，看是否在四柱地支中）
  const guiRen = TIANYI_GUIREN[dayGan] || [];
  if (guiRen.includes(pillarZhi)) {
    result.push('天乙');
  }
  
  // 文昌（按日干查）
  const wenchangZhi = WENCHANG[dayGan];
  if (pillarZhi === wenchangZhi) {
    result.push('文昌');
  }
  
  // 驿马（按年支查）
  const yimaZhi = YIMA[yearZhi];
  if (pillarZhi === yimaZhi) {
    result.push('驿马');
  }
  
  // 桃花（按年支查）
  const taohuaZhi = TAOHUA[yearZhi];
  if (pillarZhi === taohuaZhi) {
    result.push('桃花');
  }
  
  // 华盖（按年支查）
  const huagaiZhi = HUAGAI[yearZhi];
  if (pillarZhi === huagaiZhi) {
    result.push('华盖');
  }
  
  // 羊刃（按日干阳干查）
  const yangrenZhi = YANGREN[dayGan];
  if (pillarZhi === yangrenZhi) {
    result.push('羊刃');
  }
  
  // 禄神（按日干查）
  const luZhi = LUSHEN[dayGan];
  if (pillarZhi === luZhi) {
    result.push('禄神');
  }
  
  return result;
}

interface BaziChartProps {
  solar: Solar;
  lunar: Lunar;
  gender: 'male' | 'female';
  isFullscreen?: boolean;
  onFullscreenChange?: (isFullscreen: boolean) => void;
}

export function BaziChart({ solar, lunar, gender, isFullscreen = false, onFullscreenChange }: BaziChartProps) {
  const [showDayun, setShowDayun] = useState(true);
  const [dayunIndex, setDayunIndex] = useState(0);

  const baziData = useMemo(() => {
    // 四柱: lunar-javascript日柱计算经过Julian Day独立验证, 结果正确
    const eightChar = lunar.getEightChar();
    
    // 晚子时(23:00-24:00)子初换日: 日柱归属次日
    // lunar-javascript的时柱已按次日日干推算, 但日柱仍用当日
    // 需要用次日获取正确的日柱
    const isLateZiHour = solar.getHour() >= 23;
    const nextDaySolar = isLateZiHour
      ? Solar.fromDate(new Date(solar.getYear(), solar.getMonth() - 1, solar.getDay() + 1, 0, 0, 0))
      : null;
    const nextDayEightChar = nextDaySolar ? nextDaySolar.getLunar().getEightChar() : null;
    
    const yearGan = eightChar.getYearGan();
    const yearZhi = eightChar.getYearZhi();
    const monthGan = eightChar.getMonthGan();
    const monthZhi = eightChar.getMonthZhi();
    // 晚子时日柱用次日, 其余用当日
    const dayGan = isLateZiHour && nextDayEightChar ? nextDayEightChar.getDayGan() : eightChar.getDayGan();
    const dayZhi = isLateZiHour && nextDayEightChar ? nextDayEightChar.getDayZhi() : eightChar.getDayZhi();
    const hourGan = eightChar.getTimeGan();
    const hourZhi = eightChar.getTimeZhi();

    // 天干十神
    const yearShiShenGan = calculateShiShen(dayGan, yearGan);
    const monthShiShenGan = calculateShiShen(dayGan, monthGan);
    const hourShiShenGan = calculateShiShen(dayGan, hourGan);

    // 藏干及十神
    const hideGanData = {
      year: ZHI_HIDE_GAN[yearZhi] || [],
      month: ZHI_HIDE_GAN[monthZhi] || [],
      day: ZHI_HIDE_GAN[dayZhi] || [],
      hour: ZHI_HIDE_GAN[hourZhi] || [],
    };
    
    // 藏干十神
    const hideGanShiShen = {
      year: hideGanData.year.map(g => calculateShiShen(dayGan, g)),
      month: hideGanData.month.map(g => calculateShiShen(dayGan, g)),
      day: hideGanData.day.map(g => calculateShiShen(dayGan, g)),
      hour: hideGanData.hour.map(g => calculateShiShen(dayGan, g)),
    };

    // 四柱神煞
    const allZhi = [yearZhi, monthZhi, dayZhi, hourZhi];
    const pillarShenSha = {
      year: calculatePillarShenSha(dayGan, yearZhi, yearZhi, allZhi),
      month: calculatePillarShenSha(dayGan, monthZhi, yearZhi, allZhi),
      day: calculatePillarShenSha(dayGan, dayZhi, yearZhi, allZhi),
      hour: calculatePillarShenSha(dayGan, hourZhi, yearZhi, allZhi),
    };

    // 大运 - 自定义计算（只数节，不含中气，对齐问真八字）
    const yearGanIdx = GAN_SEQ.indexOf(yearGan);
    const isYangYear = yearGanIdx % 2 === 0;
    // 大运方向：男命阳顺阴逆，女命always顺排（问真八字排法）
    const forward = (isYangYear && gender === 'male') || (!isYangYear && gender === 'female');

    // 计算距节气天数与时辰差——lunar-python sect=1 精确算法
    // 算法来源：Yun.__compute_start (lunar-python)
    // 天数差 = end.subtract(start)，时辰差 = 时支索引差，hour=23→索引11
    // month = dayDiff*4 + int(hourDiff*10/30), year = int(month/12)
    // 起运虚岁 = 起运阳历年 - 出生年 + 1
    let startAge: number = 1;
    let startYear: number = solar.getYear();

    // 获取节气的阳历日期
    const jie = forward ? lunar.getNextJie() : lunar.getPrevJie();
    if (jie) {
      const jieSolar = jie.getSolar();
      // 确定 end(start 和 end（与 lunar-python 一致）
      // forward: end = nextJie, start = birth
      // backward: end = birth, start = prevJie
      const endSolar = forward ? jieSolar : solar;
      const startSolarTmp = forward ? solar : jieSolar;

      // 天数差（只计日期，不计时间）
      const endD = new Date(endSolar.getYear(), endSolar.getMonth() - 1, endSolar.getDay());
      const startD = new Date(startSolarTmp.getYear(), startSolarTmp.getMonth() - 1, startSolarTmp.getDay());
      let dayDiff = Math.round((endD.getTime() - startD.getTime()) / 86400000);

      // 时辰索引（hour=23→11=亥时，与 lunar-python 一致）
      const getTimeZhiIdx = (h: number, m: number): number => {
        if (h === 23) return 11;
        return Math.floor((h + 1) % 24 / 2);
      };
      let hourDiff = getTimeZhiIdx(endSolar.getHour(), endSolar.getMinute())
                   - getTimeZhiIdx(startSolarTmp.getHour(), startSolarTmp.getMinute());
      if (hourDiff < 0) {
        hourDiff += 12;
        dayDiff -= 1;
      }

      const monthDiff = Math.floor(hourDiff * 10 / 30);
      let month = dayDiff * 4 + monthDiff;
      const day = hourDiff * 10 - monthDiff * 30;
      const year = Math.floor(month / 12);
      month = month - year * 12;

      // 起运阳历日期（Yun.getStartSolar）
      const startDate = new Date(solar.getYear(), solar.getMonth() - 1, solar.getDay());
      startDate.setFullYear(startDate.getFullYear() + year);
      startDate.setMonth(startDate.getMonth() + month);
      startDate.setDate(startDate.getDate() + day);

      startAge = startDate.getFullYear() - solar.getYear() + 1;
      startYear = startDate.getFullYear();
    }

    // 月柱干支索引
    const monthGanIdx = GAN_SEQ.indexOf(monthGan);
    const monthZhiIdx = ZHI_SEQ.indexOf(monthZhi);
    const dir = forward ? 1 : -1;

    // 排8步大运
    const daYunList: Array<{
      ganZhi: string;
      startAge: number;
      endAge: number;
      startYear: number;
      endYear: number;
    }> = [];
    for (let i = 0; i < 8; i++) {
      const ganIdx = (monthGanIdx + (i + 1) * dir + 10) % 10;
      const zhiIdx = (monthZhiIdx + (i + 1) * dir + 12) % 12;
      const age = startAge + i * 10;
      const year = startYear + i * 10;
      daYunList.push({
        ganZhi: GAN_SEQ[ganIdx] + ZHI_SEQ[zhiIdx],
        startAge: age,
        endAge: age + 9,
        startYear: year,
        endYear: year + 9,
      });
    }
    
    // 当前流年干支
    const now = new Date();
    const currentYear = GAN_SEQ[(now.getFullYear() - 4) % 10] + ZHI_SEQ[(now.getFullYear() - 4) % 12];
    
    // 五行统计（细化到藏干）
    const wuxingCount: Record<string, { gan: number; zhi: number; hide: number }> = {
      '木': { gan: 0, zhi: 0, hide: 0 },
      '火': { gan: 0, zhi: 0, hide: 0 },
      '土': { gan: 0, zhi: 0, hide: 0 },
      '金': { gan: 0, zhi: 0, hide: 0 },
      '水': { gan: 0, zhi: 0, hide: 0 },
    };
    
    // 天干五行统计
    [yearGan, monthGan, dayGan, hourGan].forEach(g => {
      const wx = GAN_WUXING[g];
      wuxingCount[wx].gan += 1;
    });
    
    // 地支本气五行统计
    [yearZhi, monthZhi, dayZhi, hourZhi].forEach(z => {
      const wx = ZHI_WUXING[z];
      wuxingCount[wx].zhi += 1;
    });
    
    // 藏干五行统计
    Object.values(hideGanData).flat().forEach(g => {
      const wx = GAN_WUXING[g];
      wuxingCount[wx].hide += 1;
    });

    // 小运计算（1~10岁，从时柱起排）
    // 醉醒子法：阳男阴女顺排，阴男阳女逆排，1岁=时柱±1步
    const hourGanIdx = GAN_SEQ.indexOf(hourGan);
    const hourZhiIdx = ZHI_SEQ.indexOf(hourZhi);
    const xiaoYunForward = (isYangYear && gender === 'male') || (!isYangYear && gender === 'female');
    const xiaoYunDir = xiaoYunForward ? 1 : -1;
    const xiaoYunList: Array<{
      age: number;
      ganZhi: string;
      year: number;
      liuNian: string;
    }> = [];
    for (let i = 0; i < 10; i++) {
      const step = i + 1;
      const ganIdx = (hourGanIdx + step * xiaoYunDir + 10) % 10;
      const zhiIdx = (hourZhiIdx + step * xiaoYunDir + 12) % 12;
      const year = solar.getYear() + i;
      const liuNian = GAN_SEQ[(year - 4) % 10] + ZHI_SEQ[(year - 4) % 12];
      xiaoYunList.push({
        age: i + 1,
        ganZhi: GAN_SEQ[ganIdx] + ZHI_SEQ[zhiIdx],
        year,
        liuNian,
      });
    }

    // 纳音
    const yearNaYin = eightChar.getYearNaYin();
    const monthNaYin = eightChar.getMonthNaYin();
    const dayNaYin = eightChar.getDayNaYin();
    const hourNaYin = eightChar.getTimeNaYin();

    return {
      pillars: {
        year: { 
          gan: yearGan, 
          zhi: yearZhi, 
          shishenGan: yearShiShenGan, 
          hideGan: hideGanData.year,
          hideGanShiShen: hideGanShiShen.year,
          shenSha: pillarShenSha.year,
          naYin: yearNaYin 
        },
        month: { 
          gan: monthGan, 
          zhi: monthZhi, 
          shishenGan: monthShiShenGan, 
          hideGan: hideGanData.month,
          hideGanShiShen: hideGanShiShen.month,
          shenSha: pillarShenSha.month,
          naYin: monthNaYin 
        },
        day: { 
          gan: dayGan, 
          zhi: dayZhi, 
          shishenGan: '日主', 
          hideGan: hideGanData.day,
          hideGanShiShen: hideGanShiShen.day,
          shenSha: pillarShenSha.day,
          naYin: dayNaYin 
        },
        hour: { 
          gan: hourGan, 
          zhi: hourZhi, 
          shishenGan: hourShiShenGan, 
          hideGan: hideGanData.hour,
          hideGanShiShen: hideGanShiShen.hour,
          shenSha: pillarShenSha.hour,
          naYin: hourNaYin 
        },
      },
      daYunList,
      xiaoYunList,
      startAge,
      startYear,
      currentYear,
      currentAge: now.getFullYear() - solar.getYear() + 1,
      birthYear: solar.getYear(),
      wuxingCount,
    };
  }, [solar, lunar, gender]);

  // 大运数据
  const dayunData = useMemo(() => {
    if (!baziData.daYunList) return [];
    
    return baziData.daYunList.map((dy) => {
      const startAge = dy.startAge;
      const endAge = dy.endAge;
      const ganZhi = dy.ganZhi;
      
      // 计算流年（每个大运的10年）
      const liunian: Array<{ age: number; ganZhi: string; year: number }> = [];
      for (let i = 0; i < 10; i++) {
        const age = startAge + i;
        if (age > endAge) break;
        const year = dy.startYear + i;
        // 流年干支按阳历年份对应：天干=(年-4)%10, 地支=(年-4)%12
        const ganZhi = GAN_SEQ[(year - 4) % 10] + ZHI_SEQ[(year - 4) % 12];
        liunian.push({
          age,
          ganZhi,
          year,
        });
      }
      
      return {
        ganZhi,
        startAge,
        endAge,
        startYear: dy.startYear,
        liunian,
      };
    });
  }, [baziData.daYunList]);

  // 柱名
  const pillarNames = ['年柱', '月柱', '日柱', '时柱'];
  const pillarKeys = ['year', 'month', 'day', 'hour'] as const;

  return (
    <Card className={cn(
      "bg-gradient-to-b from-[#2a2624] to-[#1a1a1a] border-[#d4c4f5]/20 shadow-lg shadow-[#d4c4f5]/5 transition-all duration-300 relative overflow-hidden",
      isFullscreen ? "fixed inset-4 z-50" : ""
    )}>
      {/* 传统纹饰背景 */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 5L22 10L27 10L24 15L27 20L22 20L20 25L18 20L13 20L16 15L13 10L18 10L20 5Z' fill='none' stroke='%23d4c4f5' stroke-width='0.3'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'repeat',
          }}
        />
      </div>
      
      <CardHeader className="relative border-b border-[#d4c4f5]/20 pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-[#d4c4f5] text-lg tracking-wider">四柱八字</CardTitle>
          {onFullscreenChange && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onFullscreenChange(!isFullscreen)}
              className="text-[#f5e6a3] hover:text-[#d4c4f5] hover:bg-[#d4c4f5]/10"
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </Button>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="relative space-y-4 pt-4">
        {/* 四柱展示 - 问真八字风格 */}
        <div className="grid grid-cols-4 gap-1">
          {pillarNames.map((label, idx) => {
            const pillar = baziData.pillars[pillarKeys[idx]];
            return (
              <div key={label} className="text-center">
                {/* 柱名 */}
                <div className="text-[13px] text-[#a0a0a0] mb-1">{label}</div>
                
                {/* 四柱框 */}
                <div className="bg-[#1a1a1a] rounded border border-[#d4c4f5]/20 overflow-hidden">
                  {/* 天干行 */}
                  <div className="py-2 border-b border-[#d4c4f5]/10">
                    <div 
                      className="text-xl font-bold"
                      style={{ color: TIAN_GAN_COLORS[pillar.gan] }}
                    >
                      {pillar.gan}
                    </div>
                    <div className="text-[13px] text-[#f5e6a3]/70 mt-0.5">
                      {SHISHEN_SHORT[pillar.shishenGan] || pillar.shishenGan}
                    </div>
                  </div>
                  
                  {/* 地支行 */}
                  <div className="py-2 border-b border-[#d4c4f5]/10">
                    <div 
                      className="text-xl font-bold"
                      style={{ color: DI_ZHI_COLORS[pillar.zhi] }}
                    >
                      {pillar.zhi}
                    </div>
                  </div>
                  
                  {/* 藏干行（带十神） */}
                  <div className="py-1.5 bg-[#2a2624]/30">
                    {pillar.hideGan.length > 0 ? (
                      <div className="space-y-0.5">
                        {pillar.hideGan.map((gan: string, i: number) => (
                          <div key={i} className="flex items-center justify-center gap-1">
                            <span 
                              className="text-sm"
                              style={{ color: TIAN_GAN_COLORS[gan] }}
                            >
                              {gan}
                            </span>
                            <span className="text-[13px] text-[#a0a0a0]/70">
                              {SHISHEN_SHORT[pillar.hideGanShiShen[i]] || ''}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-xs text-[#6a6a6a]">-</div>
                    )}
                  </div>
                  
                  {/* 神煞行 */}
                  {pillar.shenSha.length > 0 && (
                    <div className="py-1 bg-[#d4c4f5]/5">
                      <div className="flex flex-wrap justify-center gap-0.5">
                        {pillar.shenSha.map((ss: string, i: number) => (
                          <span 
                            key={i}
                            className="text-xs px-1 text-[#d4c4f5]"
                          >
                            {ss}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                {/* 纳音 */}
                <div className="text-xs text-[#a0a0a0] mt-1">{pillar.naYin}</div>
              </div>
            );
          })}
        </div>

        {/* 五行统计（细化） */}
        <div className="bg-[#2a2624]/30 rounded-lg p-3 border border-[#d4c4f5]/10">
          <div className="text-sm text-[#f5e6a3] mb-2">五行统计</div>
          <div className="grid grid-cols-5 gap-2">
            {['木', '火', '土', '金', '水'].map(wx => {
              const counts = baziData.wuxingCount[wx];
              const total = counts.gan + counts.zhi + counts.hide;
              return (
                <div key={wx} className="text-center">
                  <div style={{ color: WU_XING_COLORS[wx] }} className="text-lg font-bold">
                    {total}
                  </div>
                  <div className="text-xs text-[#a0a0a0]">{wx}</div>
                  <div className="text-xs text-[#6a6a6a] mt-0.5">
                    干{counts.gan} 支{counts.zhi} 藏{counts.hide}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 起运信息 */}
        <div className="bg-[#2a2624]/30 rounded-lg p-2 border border-[#d4c4f5]/10">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[#a0a0a0]">起运</span>
            <span className="text-[#f5e6a3]">虚岁{baziData.startAge}岁起运</span>
          </div>
        </div>

        {/* 大运（含小运作为第一项） */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-sm text-[#f5e6a3]">大运</div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDayun(!showDayun)}
              className="text-[#d4c4f5] hover:bg-[#d4c4f5]/10 h-6 px-2"
            >
              {showDayun ? '收起' : '展开'}
            </Button>
          </div>
          {showDayun && (
            <div className="bg-[#2a2624]/30 rounded-lg p-3 border border-[#d4c4f5]/10">
              <div className="flex gap-1 overflow-x-auto pb-2">
                {/* 小运（童限期）- 集成到大运列表第一项 */}
                {baziData.xiaoYunList.slice(0, baziData.startAge - 1).length > 0 && (
                  <div 
                    onClick={() => setDayunIndex(-1)}
                    className={cn(
                      "cursor-pointer px-2 py-1.5 rounded text-center min-w-[50px] transition-all",
                      dayunIndex === -1
                        ? "bg-[#f5e6a3]/20 border border-[#f5e6a3]/50" 
                        : "bg-[#2a2624]/50 hover:bg-[#f5e6a3]/10"
                    )}
                  >
                    <div className="text-[11px] text-[#f5e6a3] font-bold">小运</div>
                    <div className="text-xs text-[#a0a0a0]">1-{baziData.startAge - 1}岁</div>
                    <div className="text-[12px] text-[#6a6a6a]">{baziData.birthYear}</div>
                  </div>
                )}
                {/* 大运 */}
                {dayunData.map((dy, i: number) => (
                  <div 
                    key={i}
                    onClick={() => setDayunIndex(i)}
                    className={cn(
                      "cursor-pointer px-2 py-1.5 rounded text-center min-w-[50px] transition-all",
                      dayunIndex === i 
                        ? "bg-[#d4c4f5]/20 border border-[#d4c4f5]/50" 
                        : "bg-[#2a2624]/50 hover:bg-[#d4c4f5]/10"
                    )}
                  >
                    <div 
                      className="text-base font-bold"
                      style={{ color: TIAN_GAN_COLORS[dy.ganZhi.charAt(0)] || '#f5e6a3' }}
                    >
                      {dy.ganZhi}
                    </div>
                    <div className="text-xs text-[#a0a0a0]">{dy.startAge}-{Math.min(dy.endAge, dy.startAge + 9)}岁</div>
                    <div className="text-[12px] text-[#6a6a6a]">{dy.startYear}</div>
                  </div>
                ))}
              </div>
              {/* 选中段详细年份：小运段或大运段 */}
              {dayunIndex === -1 ? (
                // 小运段展开
                <div className="mt-2 pt-2 border-t border-[#f5e6a3]/10">
                  <div className="text-xs text-[#f5e6a3] mb-1">小运 · 每岁=小运干支+流年干支</div>
                  <div className="flex gap-0.5 overflow-x-auto">
                    {baziData.xiaoYunList.slice(0, baziData.startAge - 1).map((xy, i) => (
                      <div key={i} className="text-center px-1.5 py-0.5 min-w-[36px]">
                        <div className="flex items-center gap-0.5">
                          <span className="text-xs" style={{ color: TIAN_GAN_COLORS[xy.ganZhi.charAt(0)] || '#f5e6a3' }}>
                            {xy.ganZhi}
                          </span>
                          <span className="text-[10px] text-[#6a6a6a]">/</span>
                          <span className="text-xs" style={{ color: TIAN_GAN_COLORS[xy.liuNian.charAt(0)] || '#a0a0a0' }}>
                            {xy.liuNian}
                          </span>
                        </div>
                        <div className="text-[10px] text-[#6a6a6a]">{xy.age}岁</div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : dayunIndex >= 0 && dayunData[dayunIndex] ? (
                // 大运段展开 - 显示该大运10年的流年
                <div className="mt-2 pt-2 border-t border-[#d4c4f5]/10">
                  <div className="text-xs text-[#d4c4f5] mb-1">
                    {dayunData[dayunIndex].ganZhi}运 · 流年
                  </div>
                  <div className="flex gap-0.5 overflow-x-auto">
                    {dayunData[dayunIndex].liunian.map((ln, i) => (
                      <div key={i} className="text-center px-1.5 py-0.5 min-w-[36px]">
                        <div 
                          className="text-xs"
                          style={{ color: TIAN_GAN_COLORS[ln.ganZhi.charAt(0)] || '#f5e6a3' }}
                        >
                          {ln.ganZhi}
                        </div>
                        <div className="text-[10px] text-[#6a6a6a]">{ln.age}岁</div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}