'use client';

import { useMemo } from 'react';
import { Solar, Lunar } from 'lunar-javascript';
import { Card, CardContent } from '@/components/ui/card';

// ====== 常量 ======
const GAN = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const ZHI = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];
const LIU_YI_SAN_QI = ['戊', '己', '庚', '辛', '壬', '癸', '丁', '丙', '乙'];
const YIN_GAN_ORDER = ['乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];

// 九星原始宫位
const JIU_XING: Record<number, string> = { 1: '天蓬', 2: '天芮', 3: '天冲', 4: '天辅', 5: '天禽', 6: '天心', 7: '天柱', 8: '天任', 9: '天英' };

// 八门原始宫位（无中5宫）
const BA_MEN: Record<number, string> = { 1: '休门', 2: '死门', 3: '伤门', 4: '杜门', 6: '开门', 7: '惊门', 8: '生门', 9: '景门' };

const BA_SHEN_ORDER = ['值符', '螣蛇', '太阴', '六合', '白虎', '玄武', '九地', '九天'];
const BA_SHEN_SHORT: Record<string, string> = { '值符': '符', '螣蛇': '蛇', '太阴': '阴', '六合': '合', '白虎': '白', '玄武': '玄', '九地': '地', '九天': '天' };

const XUN = ['甲子', '甲戌', '甲申', '甲午', '甲辰', '甲寅'];
const XUN_DUN: Record<string, string> = { '甲子': '戊', '甲戌': '己', '甲申': '庚', '甲午': '辛', '甲辰': '壬', '甲寅': '癸' };

// 八宫顺时针轨迹：巽4→离9→坤2→兑7→乾6→坎1→艮8→震3
const BA_MEN_SHUN = [4, 9, 2, 7, 6, 1, 8, 3];
// 八宫逆时针轨迹：震3→艮8→坎1→乾6→兑7→坤2→离9→巽4
const BA_MEN_NI = [3, 8, 1, 6, 7, 2, 9, 4];

// 入墓：阳干墓戌丑辰未，阴干墓戌丑辰未
const RU_MU: Record<string, number> = {
  '甲': 2, '丙': 6, '戊': 6, '庚': 8, '壬': 4,
  '乙': 6, '丁': 8, '己': 2, '辛': 4, '癸': 2,
};

// 击刑：六仪击刑
const JI_XING: Record<string, number[]> = {
  '戊': [3], '己': [2], '庚': [8], '辛': [9], '壬': [4], '癸': [4, 8],
};

// 门迫：门克宫（伤/杜木克坤艮土，景火克乾兑金，死土克坎水，惊/开金克震巽木）
// 八门五行（门克宫为迫）
const MEN_WUXING: Record<string, string> = {
  '休门': '水', '生门': '土', '伤门': '木', '杜门': '木',
  '景门': '火', '死门': '土', '惊门': '金', '开门': '金',
};
const GONG_WUXING: Record<number, string> = {
  1: '水', 2: '土', 3: '木', 4: '木', 5: '土', 6: '金', 7: '金', 8: '土', 9: '火',
};
const WUXING_KE: Record<string, string> = {
  '水': '火', '火': '金', '金': '木', '木': '土', '土': '水',
};
// 判断门迫（门克宫为迫）
function isMenPo(menName: string, gong: number): boolean {
  const menWx = MEN_WUXING[menName];
  const gongWx = GONG_WUXING[gong];
  return !!(menWx && gongWx && WUXING_KE[menWx] === gongWx);
}

// 空亡：旬首→地支索引(0-based)
const KONG_WANG: Record<string, number[]> = { '甲子': [10, 11], '甲戌': [8, 9], '甲申': [6, 7], '甲午': [4, 5], '甲辰': [2, 3], '甲寅': [0, 1] };
const ZHI_GONG: Record<string, number> = { '子': 1, '丑': 8, '寅': 8, '卯': 3, '辰': 4, '巳': 4, '午': 9, '未': 2, '申': 7, '酉': 7, '戌': 6, '亥': 6 };



const GONG_NAME: Record<number, string> = { 1: '坎', 2: '坤', 3: '震', 4: '巽', 5: '中', 6: '乾', 7: '兑', 8: '艮', 9: '离' };

function ganZhiTo60(ganIdx: number, zhiIdx: number): number {
  return ((6 * ganIdx - 5 * zhiIdx) % 60 + 60) % 60;
}

// 阴阳遁判定：冬至后~夏至前=阳遁，夏至后~冬至前=阴遁
function getYinYang(month: number, day: number): boolean {
  if (month > 6 && month < 12) return false;
  if (month === 6 && day >= 21) return false;
  if (month === 12 && day >= 22) return true;
  return true;
}

// 顺时针步数：从原始宫到目标宫沿BA_MEN_SHUN的顺时针步数
function getClockwiseSteps(fromGong: number, toGong: number): number {
  const fromIdx = BA_MEN_SHUN.indexOf(fromGong);
  const toIdx = BA_MEN_SHUN.indexOf(toGong);
  if (fromIdx === -1 || toIdx === -1) return 0;
  return (toIdx - fromIdx + 8) % 8;
}

// 四害详情：每个干独立标注
interface GongHarms {
  tianMu: number[];    // 天盘干中哪些字符入墓
  diMu: number[];      // 地盘干中哪些字符入墓
  yinMu: number[];     // 引干中哪些字符入墓
  tianXing: number[];  // 天盘干中哪些字符击刑
  diXing: number[];    // 地盘干中哪些字符击刑
  yinXing: number[];   // 引干中哪些字符击刑
  menPo: boolean;      // 门迫
  kong: boolean;       // 空亡
}

// ====== 阴盘命理奇门计算（王凤麟体系·转盘式） ======
interface QimenResult {
  isYang: boolean;
  juShu: number;
  xunShou: string;
  xunDunYi: string;
  zhiFuXing: string;
  zhiShiMen: string;
  shiGanGong: number;
  diPan: Record<number, string>;
  tianPan: Record<number, string>;
  jiuXing: Record<number, string>;
  baMen: Record<number, string>;
  baShen: Record<number, string>;
  yinGan: Record<number, string>;
  harms: Record<number, GongHarms>;
  steps: number;
  stepsMen: number;
  tianQinGong: number;
}

function calculateYinPanQimen(solar: Solar, lunar: any): QimenResult {
  const eightChar = lunar.getEightChar();
  const yearGZ = lunar.getYearInGanZhiExact();
  const yearZhi = yearGZ[1];
  const yearZhiIdx = ZHI.indexOf(yearZhi) + 1;
  const lunarMonth = lunar.getMonth();
  const lunarDay = lunar.getDay();
  const timeGZ = eightChar.getTime();
  const shiGan = timeGZ[0];
  const shiZhi = timeGZ[1];
  const shiGanIdx = GAN.indexOf(shiGan);
  const shiZhiIdx = ZHI.indexOf(shiZhi);
  const timeZhiIdx = shiZhiIdx + 1;

  // 1. 定局
  const sum = yearZhiIdx + lunarMonth + lunarDay + timeZhiIdx;
  const juShu = sum % 9 === 0 ? 9 : sum % 9;
  const isYang = getYinYang(solar.getMonth(), solar.getDay());

  // 2. 旬首
  const shiGZ60 = ganZhiTo60(shiGanIdx, shiZhiIdx);
  const xunIdx = Math.floor(shiGZ60 / 10);
  const xunShou = XUN[xunIdx];
  const xunDunYi = XUN_DUN[xunShou];

  // 3. 地盘
  const diPan: Record<number, string> = {};
  for (let i = 0; i < 9; i++) {
    const gong = isYang
      ? ((juShu - 1 + i) % 9) + 1
      : ((juShu - 1 - i) % 9 + 9) % 9 + 1;
    diPan[gong] = LIU_YI_SAN_QI[i];
  }

  // 旬首遁仪所在地盘宫 → 值符星/值使门
  const xunGong = parseInt(Object.entries(diPan).find(([, v]) => v === xunDunYi)?.[0] || '0');
  const xunGongEff = xunGong === 5 ? 2 : xunGong;
  const zhiFuXing = JIU_XING[xunGongEff];
  const zhiFuXingYuanGong = xunGongEff;
  const zhiShiMen = BA_MEN[xunGongEff];
  const zhiShiMenYuanGong = xunGongEff;

  // 时干所在地盘宫
  const shiGanGong = parseInt(Object.entries(diPan).find(([, v]) => v === shiGan)?.[0] || '0');
  const shiGanGongEff = shiGanGong === 5 ? 2 : shiGanGong;

  // 4. 天盘九星（转盘式）
  const steps = getClockwiseSteps(zhiFuXingYuanGong, shiGanGongEff);

  const JIU_XING_ROTATE: Record<number, string> = {};
  for (let g = 1; g <= 9; g++) {
    if (g === 5) continue;
    JIU_XING_ROTATE[g] = (g === 2) ? '天芮' : JIU_XING[g];
  }

  const jiuXing: Record<number, string> = {};
  jiuXing[5] = '';
  let tianQinGong = 0;

  for (let g = 1; g <= 9; g++) {
    if (g === 5) continue;
    const starName = JIU_XING_ROTATE[g];
    if (!starName) continue;
    const origIdx = BA_MEN_SHUN.indexOf(g);
    if (origIdx === -1) continue;
    const newIdx = (origIdx + steps) % 8;
    const newGong = BA_MEN_SHUN[newIdx];
    jiuXing[newGong] = starName;
    if (g === 2) tianQinGong = newGong;
  }

  // 5. 天盘干
  const tianPan: Record<number, string> = {};
  for (let g = 1; g <= 9; g++) {
    const starName = jiuXing[g];
    if (!starName) continue;
    let starYuanGong = parseInt(Object.entries(JIU_XING).find(([, v]) => v === starName)?.[0] || '0');
    if (starYuanGong === 5) starYuanGong = 2;
    tianPan[g] = diPan[starYuanGong];
  }

  // 天禽带中5宫地盘干（不是固定戊！）
  if (tianQinGong > 0) {
    tianPan[tianQinGong] = tianPan[tianQinGong] + (diPan[5] || '');
  }

  // 6. 八门（转盘式）
  const stepsMen = getClockwiseSteps(zhiShiMenYuanGong, shiGanGongEff);
  const baMen: Record<number, string> = {};
  baMen[5] = '';
  for (let g = 1; g <= 9; g++) {
    if (g === 5) continue;
    const menName = BA_MEN[g];
    if (!menName) continue;
    const origIdx = BA_MEN_SHUN.indexOf(g);
    if (origIdx === -1) continue;
    const newIdx = (origIdx + stepsMen) % 8;
    const newGong = BA_MEN_SHUN[newIdx];
    baMen[newGong] = menName;
  }

  // 7. 八神（逆时针）
  const baShen: Record<number, string> = {};
  baShen[5] = '';
  const shenStartIdx = BA_MEN_NI.indexOf(shiGanGongEff);
  for (let i = 0; i < 8; i++) {
    baShen[BA_MEN_NI[(shenStartIdx + i) % 8]] = BA_SHEN_ORDER[i];
  }

  // 8. 引干（暗干）：时干加值使门落宫，阳遁顺飞九宫，阴遁逆飞九宫
  // 飞布按自然数序：阳遁1→2→3→4→5→6→7→8→9，阴遁9→8→7→6→5→4→3→2→1
  // 天干顺序：三奇六仪（戊己庚辛壬癸丁丙乙），时干起始终顺排
  // 王凤麟阴盘奇门算法
  const yinGan: Record<number, string> = {};

  const zhiShiMenGong = (() => {
    const origIdx = BA_MEN_SHUN.indexOf(zhiShiMenYuanGong);
    const newIdx = (origIdx + stepsMen) % 8;
    return BA_MEN_SHUN[newIdx];
  })();
  // 时干在三奇六仪中的索引
  const shiGanIdxYin = LIU_YI_SAN_QI.indexOf(shiGan);
  // 按自然数序布9宫，天干始终顺排
  for (let i = 0; i < 9; i++) {
    // 九宫顺序：阳遁顺飞1→2→3→4→5→6→7→8→9，阴遁逆飞9→8→7→6→5→4→3→2→1
    const gong = isYang
      ? ((zhiShiMenGong - 1 + i) % 9) + 1
      : ((zhiShiMenGong - 1 - i) % 9 + 9) % 9 + 1;
    // 天干始终顺排（从时干起，沿三奇六仪顺序）
    const ganIdx = (shiGanIdxYin + i) % 9;
    yinGan[gong] = LIU_YI_SAN_QI[ganIdx];
  }
  // 中5寄坤2：引干
  if (yinGan[5]) {
    yinGan[2] = (yinGan[2] || '') + yinGan[5];
  }

  // 9. 四害（每个干独立标注）
  const harms: Record<number, GongHarms> = {};
  for (let g = 1; g <= 9; g++) {
    if (g === 5) { harms[5] = { tianMu: [], diMu: [], yinMu: [], tianXing: [], diXing: [], yinXing: [], menPo: false, kong: false }; continue; }

    const h: GongHarms = { tianMu: [], diMu: [], yinMu: [], tianXing: [], diXing: [], yinXing: [], menPo: false, kong: false };

    // 天盘干：每个干独立检查入墓和击刑
    const tianGan = tianPan[g];
    if (tianGan) {
      for (let i = 0; i < tianGan.length; i++) {
        const tg = tianGan[i];
        if (RU_MU[tg] === g) h.tianMu.push(i);
        const jx = JI_XING[tg];
        if (jx && jx.includes(g)) h.tianXing.push(i);
      }
    }

    // 地盘干：每个干独立检查
    const diGan = diPan[g] || '';
    for (let i = 0; i < diGan.length; i++) {
      const dg = diGan[i];
      if (RU_MU[dg] === g) h.diMu.push(i);
      const jx = JI_XING[dg];
      if (jx && jx.includes(g)) h.diXing.push(i);
    }

    // 引干：每个干独立检查
    const yinG = yinGan[g] || '';
    for (let i = 0; i < yinG.length; i++) {
      const yg = yinG[i];
      if (RU_MU[yg] === g) h.yinMu.push(i);
      const jx = JI_XING[yg];
      if (jx && jx.includes(g)) h.yinXing.push(i);
    }

    // 门迫（五行克宫为迫）
    const menName = baMen[g];
    if (menName) {
      const menWx = MEN_WUXING[menName];
      const gongWx = GONG_WUXING[g];
      if (menWx && gongWx && WUXING_KE[menWx] === gongWx) {
        h.menPo = true;
      }
    }

    // 空亡（宫位级别）
    const kwZhis = KONG_WANG[xunShou] || [];
    for (const zhiIdx of kwZhis) {
      if (zhiIdx >= 0 && zhiIdx < 12 && ZHI_GONG[ZHI[zhiIdx]] === g) {
        h.kong = true; break;
      }
    }

    harms[g] = h;
  }

  // 坤2宫地盘干：双干（坤2自己的地盘干 + 中5宫的地盘干）
  const diPanDisplay = { ...diPan };
  diPanDisplay[2] = diPan[2] + diPan[5]; // 坤2=坤2干+中5干

  return {
    isYang, juShu, xunShou, xunDunYi,
    zhiFuXing, zhiShiMen, shiGanGong,
    diPan: diPanDisplay, tianPan, jiuXing, baMen, baShen, yinGan, harms,
    steps, stepsMen, tianQinGong,
  };
}

// ====== 组件 ======
interface QimenChartProps {
  solar: Solar;
  lunar: Lunar;
  gender: 'male' | 'female';
  fourPillars: { year: string; month: string; day: string; hour: string; };
  isFullscreen?: boolean;
  onFullscreenChange?: (is: boolean) => void;
}

export default function QimenChart({ solar, lunar, gender, fourPillars, isFullscreen, onFullscreenChange }: QimenChartProps) {
  const qimenData = useMemo(() => {
    if (!solar || !lunar) return null;
    return calculateYinPanQimen(solar, lunar);
  }, [solar, lunar]);

  if (!qimenData) return null;

  const { isYang, juShu, xunShou, zhiFuXing, zhiShiMen, diPan, tianPan, jiuXing, baMen, baShen, yinGan, harms } = qimenData;

  const GRID_9 = [4, 9, 2, 3, 5, 7, 8, 1, 6];
  const rows = [
    [GRID_9[0], GRID_9[1], GRID_9[2]],
    [GRID_9[3], GRID_9[4], GRID_9[5]],
    [GRID_9[6], GRID_9[7], GRID_9[8]],
  ];

  function renderGong(gong: number) {
    const h = harms[gong] || { tianMu: [], diMu: [], yinMu: [], tianXing: [], diXing: [], yinXing: [], menPo: false, kong: false };
    const gongName = GONG_NAME[gong];
    const isCenter = gong === 5;

    const tianPanText = tianPan[gong] || '';
    const diPanText = diPan[gong] || '';
    const yinGanText = yinGan[gong] || '';

    return (
      <div key={gong} className="relative border border-[#3a3634] p-2 min-h-[120px] bg-[#1e1c1a] flex flex-col">
        {/* 宫位名称 + 空亡 */}
        <div className="flex items-center justify-between text-[16px] font-bold text-[#d4c4f5] mb-0.5">
          <span>{gongName}{gong}</span>
          {h.kong && (
            <span className="text-red-400 text-[13px] font-bold">空</span>
          )}
        </div>

        {isCenter ? (
          /* 中5宫：四柱八字，每柱一列，干上支下 */
          <div className="flex-1 flex items-center justify-center">
            <div className="grid grid-cols-4 gap-2">
              {[fourPillars.year, fourPillars.month, fourPillars.day, fourPillars.hour].map((gz, i) => (
                <div key={i} className="flex flex-col items-center text-[18px] font-bold text-[#f5e6a3]">
                  <span className="leading-tight">{gz[0]}</span>
                  <span className="leading-tight">{gz[1]}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* 三列布局：大字清晰 */}
            <div className="flex-1 grid grid-cols-3 gap-0 text-[14px] leading-tight">
              {/* 左列：八神(1字) + 九星 */}
              <div className="flex flex-col items-center border-r border-[#3a3634] pr-0.5 gap-0.5">
                <div className="text-[#f5e6a3] font-bold text-[18px]">{BA_SHEN_SHORT[baShen[gong]] || '—'}</div>
                <div className="text-[#88ccff] text-[14px]">{jiuXing[gong] || '—'}</div>
              </div>

              {/* 中列：八门 + 门迫标注 */}
              <div className="flex flex-col items-center justify-center border-r border-[#3a3634] px-0.5">
                <div className="text-[#a8e6cf] font-bold text-[18px]">
                  {baMen[gong] || '—'}
                  {h.menPo && <span className="text-red-400 text-[13px] font-bold ml-0.5">(迫)</span>}
                </div>
              </div>

              {/* 右列：天盘干(每个干独立标注墓/刑) + 地盘干 */}
              <div className="flex flex-col items-center pl-0.5 gap-0.5">
                <div className="text-[14px] flex flex-wrap justify-center gap-x-0.5">
                  {tianPanText ? tianPanText.split('').map((c, i) => (
                    <span key={i} className={
                      h.tianMu.includes(i) || h.tianXing.includes(i)
                        ? 'text-[#ff6b6b] font-bold'
                        : 'text-[#ffcc88]'
                    }>
                      {c}{h.tianMu.includes(i) ? '(墓)' : h.tianXing.includes(i) ? '(刑)' : ''}
                    </span>
                  )) : <span className="text-[#ffcc88]">—</span>}
                </div>
                <div className="text-[#999] text-[14px] flex flex-wrap justify-center gap-x-0.5">
                  {diPanText ? diPanText.split('').map((c, i) => (
                    <span key={i} className={
                      h.diMu.includes(i) || h.diXing.includes(i)
                        ? 'text-[#ff6b6b] font-bold'
                        : 'text-[#999]'
                    }>
                      {c}{h.diMu.includes(i) ? '(墓)' : h.diXing.includes(i) ? '(刑)' : ''}
                    </span>
                  )) : <span className="text-[#999]">—</span>}
                </div>
              </div>
            </div>
            {/* 引干 */}
            {yinGanText && (
              <div className="text-[12px] text-[#888] mt-0.5 text-center">
                <span className="text-[#666]">引:</span>
                {yinGanText.split('').map((c, i) => (
                  <span key={i} className={
                    h.yinMu.includes(i) || h.yinXing.includes(i)
                      ? 'text-[#ff6b6b] font-bold'
                      : ''
                  }>
                    {c}{h.yinMu.includes(i) ? '(墓)' : h.yinXing.includes(i) ? '(刑)' : ''}
                  </span>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    );
  }

  return (
    <Card className="bg-[#1a1a1a] border-[#2a2624]">
      <CardContent className="p-2">
        {/* 标题 */}
        <div className="text-center mb-1.5">
          <h3 className="text-[15px] font-bold text-[#d4c4f5]">奇门遁甲 · 阴盘命理</h3>
          <div className="text-[13px] text-[#a0a0a0]">
            {isYang ? '阳' : '阴'}遁{juShu}局 · 旬首{xunShou} · 值符{zhiFuXing} · 值使{zhiShiMen}
          </div>
        </div>

        {/* 九宫格 */}
        <div className="grid grid-cols-3 gap-0.5 border border-[#3a3634]">
          {rows.flat().map(gong => renderGong(gong))}
        </div>

        {/* 四害图例 */}
        <div className="flex flex-wrap gap-3 mt-1 text-[12px] text-gray-400 justify-center">
          <span className="text-red-400">(墓)=入墓</span>
          <span className="text-red-400">(刑)=击刑</span>
          <span className="text-red-400">(迫)=门迫</span>
          <span className="text-red-400">空=空亡</span>
        </div>

        {/* 隐藏DEBUG */}
        <pre id="qimen-debug" style={{display:'none'}}>
{JSON.stringify({
  局数: juShu,
  阴阳遁: isYang ? '阳' : '阴',
  旬首: xunShou,
  值符: zhiFuXing,
  值使: zhiShiMen,
  九宫: {
    乾6: {八神: baShen[6], 九星: jiuXing[6], 八门: baMen[6], 天盘干: tianPan[6], 地盘干: diPan[6], 引干: yinGan[6], 四害: harms[6]},
    坎1: {八神: baShen[1], 九星: jiuXing[1], 八门: baMen[1], 天盘干: tianPan[1], 地盘干: diPan[1], 引干: yinGan[1], 四害: harms[1]},
    艮8: {八神: baShen[8], 九星: jiuXing[8], 八门: baMen[8], 天盘干: tianPan[8], 地盘干: diPan[8], 引干: yinGan[8], 四害: harms[8]},
    震3: {八神: baShen[3], 九星: jiuXing[3], 八门: baMen[3], 天盘干: tianPan[3], 地盘干: diPan[3], 引干: yinGan[3], 四害: harms[3]},
    巽4: {八神: baShen[4], 九星: jiuXing[4], 八门: baMen[4], 天盘干: tianPan[4], 地盘干: diPan[4], 引干: yinGan[4], 四害: harms[4]},
    离9: {八神: baShen[9], 九星: jiuXing[9], 八门: baMen[9], 天盘干: tianPan[9], 地盘干: diPan[9], 引干: yinGan[9], 四害: harms[9]},
    坤2: {八神: baShen[2], 九星: jiuXing[2], 八门: baMen[2], 天盘干: tianPan[2], 地盘干: diPan[2], 引干: yinGan[2], 四害: harms[2]},
    兑7: {八神: baShen[7], 九星: jiuXing[7], 八门: baMen[7], 天盘干: tianPan[7], 地盘干: diPan[7], 引干: yinGan[7], 四害: harms[7]},
  }
}, null, 2)}
        </pre>
      </CardContent>
    </Card>
  );
}