import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: '天赋自在命理工具箱',
    template: '%s | 天赋自在',
  },
  description:
    '天赋自在命理工具箱，集四柱八字、紫微斗数、奇门遁甲、西方占星于一体的专业命理排盘工具，精确计算中国传统历法和西方天文历表。',
  keywords: [
    '天赋自在',
    '命理',
    '八字',
    '紫微斗数',
    '奇门遁甲',
    '占星',
    '星盘',
    '排盘',
    '命理工具',
  ],
  authors: [{ name: '天赋自在' }],
  generator: '天赋自在命理工具箱',
  openGraph: {
    title: '天赋自在命理工具箱',
    description: '专业命理排盘工具，四大命理系统同屏展示',
    locale: 'zh_CN',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';

  return (
    <html lang="zh-CN" className="dark">
      <body className={`antialiased bg-[#1a1a1a]`}>
        {isDev && <Inspector />}
        {children}
      </body>
    </html>
  );
}
