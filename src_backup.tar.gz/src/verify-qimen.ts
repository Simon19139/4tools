// 验证脚本：直接复制 src/components/qimen-chart.tsx 的排盘逻辑
// 运行: npx tsx src/verify-qimen.ts

import { Solar } from 'lunar-javascript';

// ====== 从 qimen-chart.tsx 复制的常量 ======
const GAN = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const ZHI = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];
const LIU_YI_SAN_QI = ['戊', '己', '庚', '辛', '壬', '癸', '丁', '丙', '乙'];

const JIU_XING: Record<number, string> = { 1: '天蓬', 2: '天芮', 3: '天冲', 4: '天辅', 5: '天禽', 6: '天心', 7: '天柱', 8: '天任', 9: '天英' };
const BA_MEN: Record<number, string> = { 1: '休门', 2: '死门', 3: '伤门', 4: '杜门', 6: '开门', 7: '惊门', 8: '生门', 9: '景门' };
const BA_SHEN_ORDER = ['值符', '螣蛇', '太阴', '六合', '白虎', '玄武', '九地', '九天'];
const XUN = ['甲子', '甲戌', '甲申', '甲午', '甲辰', '甲寅'];
const XUN_DUN: Record<string, string> = { '甲子': '戊', '甲戌': '己', '甲申': '庚', '甲午': '辛', '甲辰': '壬', '甲寅': '癸' };
const BA_MEN_SHUN = [4, 9, 2, 7, 6, 1, 8, 3];
const BA_MEN_NI = [3, 8, 1, 6, 7, 2, 9, 4];
const GAN_ORDER_10 = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];

function ganZhiTo60(ganIdx: number, zhiIdx: number): number {
  return ((6 * ganIdx - 5 * zhiIdx) % 60 + 60) % 60;
}

function getYinYang(month: number, day: number): boolean {
  if (month > 6 && month < 12) return false;
  if (month === 6 && day >= 21) return false;
  if (month === 12 && day >= 22) return true;
  return true;
}

function getClockwiseSteps(fromGong: number, toGong: number): number {
  const fromIdx = BA_MEN_SHUN.indexOf(fromGong);
  const toIdx = BA_MEN_SHUN.indexOf(toGong);
  if (fromIdx === -1 || toIdx === -1) return 0;
  return (toIdx - fromIdx + 8) % 8;
}

function calculateYinPanQimen(solar: any) {
  const lunar = solar.getLunar();
  const eightChar = lunar.getEightChar();
  const yearGZ = lunar.getYearInGanZhiExact();
  const yearZhi = yearGZ[1];
  const yearZhiIdx = ZHI.indexOf(yearZhi) + 1;
  const lunarMonth = lunar.getMonth();
  const lunarDay = lunar.getDay();
  const timeGZ = eightChar.getTime();
  const shiGan = timeGZ[0];
  const shiZhi = timeGZ[1];
  const shiGanIdx = GAN.indexOf(shiGan);
  const shiZhiIdx = ZHI.indexOf(shiZhi);
  const timeZhiIdx = shiZhiIdx + 1;

  // 1. 定局
  const sum = yearZhiIdx + lunarMonth + lunarDay + timeZhiIdx;
  const juShu = sum % 9 === 0 ? 9 : sum % 9;
  const isYang = getYinYang(solar.getMonth(), solar.getDay());

  // 2. 旬首
  const shiGZ60 = ganZhiTo60(shiGanIdx, shiZhiIdx);
  const xunIdx = Math.floor(shiGZ60 / 10);
  const xunShou = XUN[xunIdx];
  const xunDunYi = XUN_DUN[xunShou];

  // 3. 地盘
  const diPan: Record<number, string> = {};
  for (let i = 0; i < 9; i++) {
    const gong = isYang
      ? ((juShu - 1 + i) % 9) + 1
      : ((juShu - 1 - i) % 9 + 9) % 9 + 1;
    diPan[gong] = LIU_YI_SAN_QI[i];
  }

  const xunGong = parseInt(Object.entries(diPan).find(([, v]) => v === xunDunYi)?.[0] || '0');
  const xunGongEff = xunGong === 5 ? 2 : xunGong;
  const zhiFuXing = JIU_XING[xunGongEff];
  const zhiShiMenYuanGong = xunGongEff;

  const shiGanGong = parseInt(Object.entries(diPan).find(([, v]) => v === shiGan)?.[0] || '0');
  const shiGanGongEff = shiGanGong === 5 ? 2 : shiGanGong;

  // 4. 天盘九星
  const steps = getClockwiseSteps(zhiShiMenYuanGong, shiGanGongEff);
  const JIU_XING_ROTATE: Record<number, string> = {};
  for (let g = 1; g <= 9; g++) {
    if (g === 5) continue;
    JIU_XING_ROTATE[g] = (g === 2) ? '天芮' : JIU_XING[g];
  }
  const jiuXing: Record<number, string> = {};
  jiuXing[5] = '';
  let tianQinGong = 0;
  for (let g = 1; g <= 9; g++) {
    if (g === 5) continue;
    const starName = JIU_XING_ROTATE[g];
    if (!starName) continue;
    const origIdx = BA_MEN_SHUN.indexOf(g);
    if (origIdx === -1) continue;
    const newIdx = (origIdx + steps) % 8;
    jiuXing[BA_MEN_SHUN[newIdx]] = starName;
    if (g === 2) tianQinGong = BA_MEN_SHUN[newIdx];
  }

  // 5. 天盘干
  const tianPan: Record<number, string> = {};
  for (let g = 1; g <= 9; g++) {
    const starName = jiuXing[g];
    if (!starName) continue;
    let starYuanGong = parseInt(Object.entries(JIU_XING).find(([, v]) => v === starName)?.[0] || '0');
    if (starYuanGong === 5) starYuanGong = 2;
    tianPan[g] = diPan[starYuanGong];
  }
  if (tianQinGong > 0) {
    tianPan[tianQinGong] = tianPan[tianQinGong] + (diPan[5] || '');
  }

  // 6. 八门
  const stepsMen = getClockwiseSteps(zhiShiMenYuanGong, shiGanGongEff);
  const baMen: Record<number, string> = {};
  baMen[5] = '';
  for (let g = 1; g <= 9; g++) {
    if (g === 5) continue;
    const menName = BA_MEN[g];
    if (!menName) continue;
    const origIdx = BA_MEN_SHUN.indexOf(g);
    if (origIdx === -1) continue;
    baMen[BA_MEN_SHUN[(origIdx + stepsMen) % 8]] = menName;
  }

  // 7. 八神
  const baShen: Record<number, string> = {};
  baShen[5] = '';
  const shenStartIdx = BA_MEN_NI.indexOf(shiGanGongEff);
  for (let i = 0; i < 8; i++) {
    baShen[BA_MEN_NI[(shenStartIdx + i) % 8]] = BA_SHEN_ORDER[i];
  }

  // 8. 引干（暗干）
  const yinGan: Record<number, string> = {};
  const zhiShiMenGong = BA_MEN_SHUN[(BA_MEN_SHUN.indexOf(zhiShiMenYuanGong) + stepsMen) % 8];
  const shiGanIdx10 = GAN_ORDER_10.indexOf(shiGan);
  for (let i = 0; i < 9; i++) {
    const gong = isYang
      ? ((zhiShiMenGong - 1 + i) % 9) + 1
      : ((zhiShiMenGong - 1 - i) % 9 + 9) % 9 + 1;
    const ganIdx = isYang
      ? (shiGanIdx10 + i) % 10
      : (shiGanIdx10 - i + 100) % 10;
    yinGan[gong] = GAN_ORDER_10[ganIdx];
  }
  if (yinGan[5]) {
    yinGan[2] = (yinGan[2] || '') + yinGan[5];
  }

  // 坤2宫地盘双干
  const diPanDisplay = { ...diPan };
  diPanDisplay[2] = diPan[2] + diPan[5];

  return {
    juShu, isYang, shiGan, shiZhi, timeGZ, xunShou, xunDunYi,
    zhiFuXing, zhiShiMenGong, shiGanGongEff, xunGongEff, stepsMen,
    diPan, diPanDisplay, tianPan, yinGan, baMen, jiuXing, baShen,
    yearGZ, lunarMonth, lunarDay
  };
}

function printCase(label: string, solar: any) {
  const r = calculateYinPanQimen(solar);

  console.log('=' .repeat(70));
  console.log(` ${label}`);
  console.log('=' .repeat(70));
  console.log(` 日柱: ${r.timeGZ ? r.timeGZ : 'N/A'} | 时柱: ${r.timeGZ} | 旬首: ${r.xunShou}(${r.xunDunYi})`);
  console.log(` 年柱: ${r.yearGZ} | 农历: ${r.lunarMonth}月${r.lunarDay}日`);
  console.log(` ${r.isYang ? '阳' : '阴'}遁${r.juShu}局 | 值符: ${r.zhiFuXing} | 值使门落宫: ${r.zhiShiMenGong}`);
  console.log(` 时干: ${r.shiGan} | 时干宫: ${r.shiGanGongEff} | 旬首宫: ${r.xunGongEff}`);
  console.log();
  console.log(' 宫位 | 地盘干 | 天盘干 | 引干     | 备注');
  console.log(' ' + '-'.repeat(50));
  for (let g = 1; g <= 9; g++) {
    const dp = r.diPanDisplay[g] || '—';
    const tp = r.tianPan[g] || '—';
    let yg = r.yinGan[g] || '—';
    let note = '';
    if (g === 2) {
      if (r.yinGan[5]) note = '引干双干: ' + r.yinGan[2];
      else if (r.diPan[5]) note = '地盘双干: ' + dp;
    }
    if (g === 5) note = '中5→坤2';
    const gongName = ['', '坎', '坤', '震', '巽', '中', '乾', '兑', '艮', '离'][g];
    console.log(`  ${gongName}${g}  | ${dp.padEnd(6)} | ${tp.padEnd(6)} | ${yg.padEnd(8)} | ${note}`);
  }
  console.log();
}

// ====== 三个用例 ======
console.log('\\n' + '#'.repeat(70));
console.log('# 奇门遁甲排盘验证 — 引干（暗干）算法');
console.log('# 使用项目实际代码逻辑 (src/components/qimen-chart.tsx)');
console.log('#'.repeat(70) + '\\n');

// 用例1: 阴遁5局 2023-09-06 午时
const s1 = Solar.fromYmdHms(2023, 9, 6, 12, 0, 0);
printCase('用例1: 2023-09-06 12:00 (午时)', s1);

// 用例2: 阴遁2局 2023-09-07 辰时
const s2 = Solar.fromYmdHms(2023, 9, 7, 8, 0, 0);
printCase('用例2: 2023-09-07 08:00 (辰时)', s2);

// 用例3: 阳遁3局 2024-02-10 午时
const s3 = Solar.fromYmdHms(2024, 2, 10, 12, 0, 0);
printCase('用例3: 2024-02-10 12:00 (午时)', s3);