declare module 'lunar-javascript' {
  export class Solar {
    static fromDate(date: Date): Solar;
    static fromYmd(year: number, month: number, day: number): Solar;
    static fromYmdHms(year: number, month: number, day: number, hour: number, minute: number, second: number): Solar;
    
    getYear(): number;
    getMonth(): number;
    getDay(): number;
    getHour(): number;
    getMinute(): number;
    getSecond(): number;
    getLunar(): Lunar;
    toString(): string;
    toDate(): Date;
  }

  export class Lunar {
    static fromDate(date: Date): Lunar;
    static fromSolar(solar: Solar): Lunar;
    static fromYmd(year: number, month: number, day: number): Lunar;
    
    getYear(): number;
    getMonth(): number;
    getDay(): number;
    getHour(): number;
    getMinute(): number;
    getYearInGanZhi(): string;
    getMonthInGanZhi(): string;
    getDayInGanZhi(): string;
    getYearGan(): string;
    getYearZhi(): string;
    getMonthGan(): string;
    getMonthZhi(): string;
    getDayGan(): string;
    getDayZhi(): string;
    getTimeGan(): string;
    getTimeZhi(): string;
    getTimeGanZhi(): string;
    getYearShengXiao(): string;
    getMonthShengXiao(): string;
    getDayShengXiao(): string;
    getYearInChinese(): string;
    getMonthInChinese(): string;
    getDayInChinese(): string;
    toString(): string;
    getPrevJieQi(): JieQi | null;
    getNextJieQi(): JieQi | null;
    getPrevJie(): JieQi | null;
    getNextJie(): JieQi | null;
    getPrevQi(): JieQi | null;
    getNextQi(): JieQi | null;
    getEightChar(): EightChar;
    getZhiRunQiMen(): QiMen;
    getZiWei(): ZiWei;
    getSolar(): Solar;
    getDayJiShen(): string[];
    getDayXiongSha(): string[];
    getShengxiao(): string;
  }

  export class JieQi {
    getName(): string;
    getSolar(): Solar;
  }

  export class EightChar {
    // 获取完整干支
    getYear(): string;
    getMonth(): string;
    getDay(): string;
    getTime(): string;
    getYearGan(): string;
    getYearZhi(): string;
    getMonthGan(): string;
    getMonthZhi(): string;
    getDayGan(): string;
    getDayZhi(): string;
    getTimeGan(): string;
    getTimeZhi(): string;
    getYearGanZhi(): string;
    getMonthGanZhi(): string;
    getDayGanZhi(): string;
    getTimeGanZhi(): string;
    // 十神 - 天干
    getYearShiShenGan(): string;
    getMonthShiShenGan(): string;
    getDayShiShenGan(): string;
    getTimeShiShenGan(): string;
    // 十神 - 地支
    getYearShiShenZhi(): string[];
    getMonthShiShenZhi(): string[];
    getDayShiShenZhi(): string[];
    getTimeShiShenZhi(): string[];
    // 藏干
    getYearHideGan(): string[];
    getMonthHideGan(): string[];
    getDayHideGan(): string[];
    getTimeHideGan(): string[];
    // 五行
    getYearWuXing(): string;
    getMonthWuXing(): string;
    getDayWuXing(): string;
    getTimeWuXing(): string;
    // 纳音
    getYearNaYin(): string;
    getMonthNaYin(): string;
    getDayNaYin(): string;
    getTimeNaYin(): string;
    // 十二长生
    getYearDiShi(): string;
    getMonthDiShi(): string;
    getDayDiShi(): string;
    getTimeDiShi(): string;
    // 旬空
    getYearXun(): string;
    getYearXunKong(): string;
    getMonthXun(): string;
    getMonthXunKong(): string;
    getDayXun(): string;
    getDayXunKong(): string;
    getTimeXun(): string;
    getTimeXunKong(): string;
    // 获取运
    getYun(gender: number): Yun;
    getLunar(): Lunar;
    toString(): string;
  }

  export class Yun {
    getDaYun(): DaYun[];
    getLunar(): Lunar;
  }

  export class DaYun {
    getStartAge(): number;
    getEndAge(): number;
    getStartYear(): number;
    getEndYear(): number;
    getGanZhi(): string;
    getLunar(): Lunar;
    getLiuNian(): LiuNian[];
    getXiaoYun(): XiaoYun[];
    getIndex(): number;
  }

  export class LiuNian {
    getAge(): number;
    getGanZhi(): string;
  }

  export class XiaoYun {
    getAge(): number;
    getGanZhi(): string;
  }

  export class QiMen {
    getJu(): number;
    getYangDun(): boolean;
    getZhiFu(): string;
    getZhiShi(): string;
    getTianPan(): string[];
    getDiPan(): string[];
    getRenPan(): string[];
    getShenPan(): string[];
    getJiuGong(): JiuGong[];
    toString(): string;
  }

  export class JiuGong {
    getIndex(): number;
    getTianPan(): string;
    getDiPan(): string;
    getRenPan(): string;
    getShenPan(): string;
    getMen(): string;
    getXing(): string;
    getGan(): string;
  }

  export class ZiWei {
    getMingGong(): ZiWeiGong;
    getShenGong(): ZiWeiGong;
    getGong(index: number): ZiWeiGong;
    getGongList(): ZiWeiGong[];
    getSiHua(): SiHua;
  }

  export class ZiWeiGong {
    getName(): string;
    getGongIndex(): number;
    getMajorStar(): string[];
    getMinorStar(): string[];
    getGan(): string;
    getZhi(): string;
    getSiHua(): string[];
  }

  export class SiHua {
    getHuaLu(): string;
    getHuaQuan(): string;
    getHuaKe(): string;
    getHuaJi(): string;
  }

  // 兼容旧 API 的别名
  export class LunarYear {}
  export class LunarMonth {}
  export class LunarDay {}
  export class LunarTime {}
}